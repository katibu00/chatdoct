<template>

<div id="main-app">
    <chatComponent />
</div>

</template>

<script>

import chatComponent from "./ChatApp.vue";

export default {
    components:{
        chatComponent
    }
}
</script>
