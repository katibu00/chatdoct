@extends('layouts.app')

@section('content')

<main-app></main-app>
@endsection

@section('js')

@endsection
