@extends('layouts.master')
@section('PageTitle','Chats')
@section('content')

<main-app></main-app>


@endsection
