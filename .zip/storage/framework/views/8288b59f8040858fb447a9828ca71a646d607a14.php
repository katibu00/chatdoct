<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta content="" name="description">
  <meta content="" name="keywords">

  <title><?php echo e(config('app.name', 'Consult Doctor Online with ChatDoc Nigeria')); ?></title>

  <!-- Favicons -->
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('/website//website/img/apple-touch-icon.png')); ?>">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/website/img/favicon-32x32.png')); ?>">
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/website/img/favicon-16x16.png')); ?>">
  <link rel="manifest" href="<?php echo e(asset('/website/img/site.webmanifest')); ?>">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  
  <link href="<?php echo e(asset('/website/vendor/animate.css/animate.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('/website/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('/website/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('/website/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('/website/vendor/glightbox/css/glightbox.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('/website/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet"> 

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('/website/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('/website/css/icofont.css')); ?>" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Green - v4.3.0
  * Template URL: https://bootstrapmade.com/green-free-one-page-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

  
<body>
    
    <!-- Page Header and Navigation-->    
    <?php echo $__env->make('front.layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 

    <!-- Page Content -->
    <main id="main">
    <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Page Footer -->
    <?php echo $__env->make('front.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>

</html><?php /**PATH C:\Users\Katibu\Desktop\Projects\chatdoc_new\resources\views/front/layouts/app.blade.php ENDPATH**/ ?>