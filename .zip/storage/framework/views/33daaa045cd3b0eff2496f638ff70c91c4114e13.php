<?php $__env->startSection('PageTitle','About Us'); ?>
<?php $__env->startSection('content'); ?>


<section id="pagetitle-container">
    <div class="uk-container">
        <div class="uk-grid">
            <div class="uk-width-1-1">
                <!-- Breadcrumb begin -->
                <ul class="uk-breadcrumb uk-margin-top uk-float-right">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Pages</a></li>
                    <li><a href="#">About</a></li>
                </ul>
                <!-- Breadcrumb end -->
            </div>
        </div>
    </div>
</section>
<section class="uk-margin-large-bottom">
    <div class="uk-container">
        <div class="uk-grid uk-margin-medium-top">
            <div class="uk-width-2-3@l uk-width-1-1@s uk-align-center uk-text-center">
                <h2 class="uk-margin-small-top uk-margin-remove-bottom">About Us</h2>
                <p class="uk-text-lead uk-margin-small-bottom">Chatdoc is a social enterprise that helps underserviced communities in Nigeria to access qualitative healthcare virtually through Telemedicine</p>
            </div>
            <div class="uk-width-1-1">
                <div class="uk-child-width-1-3@l uk-child-width-1-3@m uk-child-width-1-1@s uk-margin-top" data-uk-grid>
                    <div>
                        <div class="uk-grid-small uk-flex-top" data-uk-grid>
                            <div class="uk-width-auto uk-margin-small-right"> <i class="fa fa-3x fa-leaf uk-margin-small-top"></i> </div>
                            <div class="uk-width-expand">
                                <h3 class="uk-margin-remove-bottom idz-thin">Mission</h3>
                                <p class="uk-margin-small-top">To deliver qualitative healthcare virtually beyong geographical, cost and language barriers to under-serviced communities.</p>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="uk-grid-small uk-flex-top" data-uk-grid>
                            <div class="uk-width-auto uk-margin-small-right"> <i class="fa fa-3x fa-hourglass-end uk-margin-small-top"></i> </div>
                            <div class="uk-width-expand">
                                <h3 class="uk-margin-remove-bottom idz-thin">Vision</h3>
                                <p class="uk-margin-small-top">To have a Pan-African healthcare and well-informed societies at every stage of development.</p>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="uk-grid-small uk-flex-top" data-uk-grid>
                            <div class="uk-width-auto uk-margin-small-right"> <i class="fa fa-3x fa-flag uk-margin-small-top"></i> </div>
                            <div class="uk-width-expand">
                                <h3 class="uk-margin-remove-bottom idz-thin">Core Values</h3>
                                <p class="uk-margin-small-top"><ol><li>Hard Work</li><li>Dedication</li><li>Honesty</li></ol></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="uk-margin-medium-bottom">
    <div class="uk-container uk-container-expand uk-background-default">
        <div class="uk-container uk-margin-medium-top uk-margin-medium-bottom">
            <div class="uk-grid">
                <div class="uk-width-1-1">
                    
                    <p class="uk-text-lead uk-margin-small-bottom">Telemedicine is simply the process of delivering healthcare services to patient virtually when the doctor and the patient are not in the same physical space. The World Health Organisation (WHO) describes it as ‘The delivery of health care services, where distance is a critical factor, by all health care professionals using information and communication technologies for the exchange of valid information for diagnosis, treatment and prevention of disease and injuries, research and evaluation, and for the continuing education of health care providers, all in the interests of advancing the health of individuals and their communities.</p>
                    <p class="uk-text-lead uk-margin-small-bottom">Health crisis has been a major problem affecting Nigerians for decades. Although the country has population of about 200million people, there are inadequate human resources for health to meet up the healthcare demand of the population. The Nigerian Medical Association (NMA) reported that, out of about 80,000 registered medical doctors in Nigeria only about 40,000 are currently practicing within the country. This makes the Patient to Doctor Ratio at about 1:5000 short of World Health Organization (WHO) recommendation of 1:600.The effect of this crisis manifest in rural and semi-urban areas, because the few available healthcare personnel are concentrated in major cities. People living in rural and semi-urban areas find it difficult to access qualitative healthcare. As a result, many of them consider a chemist or pharmacy store as primary point of care while some resort to spiritualist, quacks or self-medication.</p>
                    <p class="uk-text-lead uk-margin-small-bottom">A group of young individuals consisting of medical doctors, software engineers and entrepreneurs with diverse experience and passion for healthcare brought Chatdoc as a sustainable solution to this crisis. Chatdoc brings doctors closer to the rural and under-serviced communities virtually. Through chatdoc web application, patients can speak with qualified medical doctors via Chat, Video/Audio Conference and receive e-precription, medical advice or appropriate referral at an affordable cost from comfort of their homes.</p>
                    <p class="uk-text-lead uk-margin-small-bottom">Chatdoc provides care beyond distance, cost and language barriers. Therefore patients can easily login from their phones, or computers, select the type of service based on cost and languages of the healthcare provider and speak with a Doctor.</p>
                    
                </div>
            </div>
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Katibu\Desktop\Projects\chatdoc_new\resources\views/front/about.blade.php ENDPATH**/ ?>