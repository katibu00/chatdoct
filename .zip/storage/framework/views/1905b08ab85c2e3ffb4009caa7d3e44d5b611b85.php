<?php $__env->startSection('PageTitle','Homepage'); ?>
<?php $__env->startSection('content'); ?>
<section id="slideshow-container">
    <!-- Slideshow wrapper begin -->
    <div data-uk-slideshow="autoplay: true; animation: slide; max-height: 500">
        <div class="uk-position-relative">
            <ul class="uk-slideshow-items">
                <!-- Slide 1 begin -->
                <li>
                    <div class="uk-position-cover uk-animation-kenburns uk-animation-reverse uk-transform-origin-center">
                        <img src="/front/images/content/bg1.png" alt="" uk-cover>
                    </div>
                    <div class="uk-container uk-position-center">
                        <div class="uk-grid">
                            <div class="uk-width-3-4@l uk-width-1-1@s uk-margin-medium-left">
                                <h1 class="uk-margin-small-bottom">CHAT A DOCTOR</h1>
                                <h3 class="uk-margin-small-top uk-margin-medium-bottom idz-thin uk-visible@m">We Provide Solutions to Your Healthcare Needs</h3> <a class="uk-button uk-button-danger" href="<?php echo e(route('login')); ?>">Try for Free</a>
                            </div>
                        </div>
                    </div>
                </li>
                <!-- Slide 1 end -->
    
                <!-- Slide 3 begin -->
                
                <!-- Slide 3 end -->
            </ul>
        </div>
        <ul class="uk-slideshow-nav uk-dotnav uk-flex-center uk-margin"></ul>
    </div>
    <!-- Slideshow wrapper end -->
</section>    

<section>
    <div class="uk-container">
        <div class="uk-grid">
            <div class="uk-width-1-1">
                <div class="uk-card uk-card-default uk-card-body">
                    <h2 class="uk-text-center">Our service is specifically designed to meet your healthcare needs</h2>
                    <div class="uk-child-width-1-4@l uk-child-width-1-2@m uk-child-width-1-1@s" data-uk-grid>
                        <div class="uk-text-center">    <i class="fa-solid fa-laptop-medical text-yellow mb-3" style="font-size: 60px"></i>
                            <h6 class="uk-text-uppercase uk-text-muted uk-margin-remove-top uk-margin-small-bottom">TELEMEDICINE</h6>
                            <p class="uk-margin-remove-top">Speak to your doctor via chat, video or audio call using your phone, tablet or computer at comfort of your home or office.</p>
                        </div>
                        <div class="uk-text-center">    <i class="fa-solid fa-briefcase-medical text-yellow mb-3" style="font-size: 60px"></i>
                            <h6 class="uk-text-uppercase uk-text-muted uk-margin-remove-top uk-margin-small-bottom">ELECT. HEALTH RECORD</h6>
                            <p class="uk-margin-remove-top">Upload your Test results such as Ultrasound scan and get interpretation  from medical doctor. &nbsp;
                                Receive E-prescription for medicines from your doctor.</p>
                        </div>
                        <div class="uk-text-center">    <i class="fa-solid fa-bed-pulse text-yellow mb-3" style="font-size: 60px"></i>
                            <h6 class="uk-text-uppercase uk-text-muted uk-margin-remove-top uk-margin-small-bottom">VITAL SIGNS</h6>
                            <p class="uk-margin-remove-top">Visit our Telehealth centres, partner  clinics or pharmaceutical stores and get your vital signs such as blood pressure, weight and body temperature recorded and interpreted.</p>
                        </div>
                        
                    </div>
                  
                </div>
            </div>
        </div>
    </div>
</section>
<section class="uk-margin-large-bottom idz-invest-product">
    <div class="uk-container">
        <div class="uk-grid uk-margin-small-top">
            <div class="uk-width-3-5@l uk-width-1-1@m uk-width-1-1@s">
                <h2 class="uk-margin-remove-bottom">Why ChatDoct?</h2>
                <h3 class="uk-margin-remove-top idz-thin">Work with us the way you want.</h3>
                <p class="uk-text-lead">Some believe you must choose between an online broker and a wealth management firm. At Fina, you don’t need to compromise. Whether you invest on your own, with an advisor, or a little of both — we can support you.</p>
                <div class="uk-child-width-1-3@l uk-child-width-1-3@m uk-child-width-1-2@s uk-grid-small uk-grid-match uk-margin-medium-top" data-uk-grid>
                    <div>
                        <div class="uk-card uk-card-primary uk-card-small uk-card-body uk-inline idz-invest-card green">
                            <h6 class="uk-text-uppercase uk-margin-small-bottom">COMFORT AND CONVINIENCE</h6>
                            <p class="uk-margin-remove-top">You can speak with your doctor without leaving your home or room. Therefore, you are safe from the stress of driving and wasting hours in the waiting room to see a doctor.</p>
                            <div class="uk-position-bottom-right"> <a><i class="fa fa-2x fa-angle-right"></i></a> </div>
                        </div>
                    </div>
                    <div>
                        <div class="uk-card uk-card-primary uk-card-small uk-card-body uk-inline idz-invest-card blue">
                            <h6 class="uk-text-uppercase uk-margin-small-bottom">INCREASES HEALTHCARE ACCESS TO RURAL /UNDERSERVICED COMMUNITIES </h6>
                            <p class="uk-margin-remove-top">People who are far away from hospital can easily talk to a doctor in a minute before they get extremely sick</p>
                            <div class="uk-position-bottom-right"> <a><i class="fa fa-2x fa-angle-right"></i></a> </div>
                        </div>
                    </div>
                    <div>
                        <div class="uk-card uk-card-primary uk-card-small uk-card-body uk-inline idz-invest-card purple">
                            <h6 class="uk-text-uppercase uk-margin-small-bottom">REDUCES COST OF HEALTHCARE</h6>
                            <p class="uk-margin-remove-top">Chatdoc is relatively cheaper than in person visit. It eliminates the cost of transportation and feeding that patient may pay during in-person visit to hospital.</p>
                            <div class="uk-position-bottom-right"> <a><i class="fa fa-2x fa-angle-right"></i></a> </div>
                        </div>
                    </div>
                    <div>
                        <div class="uk-card uk-card-primary uk-card-small uk-card-body uk-inline idz-invest-card midnight">
                            <h6 class="uk-text-uppercase uk-margin-small-bottom">REDUCES EXPOSURE TO DISEASES</h6>
                            <p class="uk-margin-remove-top">Chatdoc reduces the risk of contracting communicable diseases such as Covid-19 by reducing contacts between patients in the waiting room. Doctors are also protected</p>
                            <div class="uk-position-bottom-right"> <a><i class="fa fa-2x fa-angle-right"></i></a> </div>
                        </div>
                    </div>
                    <div>
                        <div class="uk-card uk-card-primary uk-card-small uk-card-body uk-inline idz-invest-card grey">
                            <h6 class="uk-text-uppercase uk-margin-small-bottom">INCREASES PRACTICE REVENUE</h6>
                            <p class="uk-margin-remove-top">Medical doctors can supplement their income by consulting patients via Chatdoc</p>
                            <div class="uk-position-bottom-right"> <a><i class="fa fa-2x fa-angle-right"></i></a> </div>
                        </div>
                    </div>
                    <div>
                        <div class="uk-card uk-card-primary uk-card-small uk-card-body uk-inline idz-invest-card orange">
                            <h6 class="uk-text-uppercase uk-margin-small-bottom">Advisor network</h6>
                            <p class="uk-margin-remove-top">Specialized guidance from independent local advisor for hight-net-worth investors</p>
                            <div class="uk-position-bottom-right"> <a><i class="fa fa-2x fa-angle-right"></i></a> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="uk-margin-top uk-margin-large-bottom">
    <div class="uk-container">
        <div class="uk-grid uk-margin-medium-top">
            <div class="uk-width-2-3@l uk-width-2-3@m uk-width-1-1@s">
                <ul data-uk-accordion="collapsible: false" class="uk-margin-medium-bottom">
                    <li>
                        <h3 class="uk-accordion-title">HOW DO I SPEAK WITH MEDICAL DOCTOR?</h3>
                        <div class="uk-accordion-content">
                            <p>Simply signup, set up your profile, fund your wallet, choose a doctor, Select type of service (chat or video) and book available time slot. When it is time, your doctor will be available for chatting or send you a video link for video consultation as the case may be.</p>
                        </div>
                    </li>
                    <li>
                        <h3 class="uk-accordion-title">ARE YOUR DOCTORS REAL?</h3>
                        <div class="uk-accordion-content">
                            <p>Yes, our doctors are MDCN(Medical and Dental Council of Nigeria) certified, And are verified by our management team.</p>
                            
                        </div>
                    </li>
                    <li>
                        <h3 class="uk-accordion-title">I DON’T HAVE A SMARTPHONE, HOW CAN I SPAEK A DOCTOR?</h3>
                        <div class="uk-accordion-content">
                            <p>Kindly visit ChatDoc Telehealth Centre, Our partner clinics or pharmaceutical stores nearest to you.</p>
                        </div>
                    </li>
                    <li>
                        <h3 class="uk-accordion-title">I FIND IT DIFFICULT TO EXPLAIN MY SYMPTOMS IN ENGLISH, WHAT SHOULD I DO?</h3>
                        <div class="uk-accordion-content">
                            <p>Chatdoc provides care beyond language barrier. Local languages of our doctors are indicated, kindly go through the platform and search for doctor who can speak your language.</p>
                        </div>
                    </li>
                    <li>
                        <h3 class="uk-accordion-title">HOW MUCH IS THE CONSULTATION FEE?</h3>
                        <div class="uk-accordion-content">
                            <p>It varies, depending on the specialty and experience of the doctor. But generally ranges between 500 to 5000 Naira</p>
                        </div>
                    </li>
                    <li>
                        <h3 class="uk-accordion-title">WHAT WILL HAPPEN IF THE DOCTOR I BOOKED IS NOT AVAILABLE AS SCHEDULED?</h3>
                        <div class="uk-accordion-content">
                            <p>Patiently wait for about 30 minutes after which booking will be cancel and you will be refunded.</p>
                        </div>
                    </li>
                    <li>
                        <h3 class="uk-accordion-title">WHAT IF THE DOCTOR I BOOKED DID NOT SEND ME PRESCRIPTON, CAN I GET REFUND?</h3>
                        <div class="uk-accordion-content">
                            <p>No, please note that our doctors charge you for consultation not prescription. He may refer you appropriately or give you some medical advice</p>
                        </div>
                    </li>
                    <li>
                        <h3 class="uk-accordion-title">CAN OTHER PATIENTS READ OUR CHATS WITH THE DOCTOR?</h3>
                        <div class="uk-accordion-content">
                            <p>No, we respect your confidentiality as a patient. Our chat system is end to end, ie between you and your doctor. Not even the admin can read your chats. But your doctor can write clinical note about your health condition which will be visible to the next doctor you are going to see, to serve as a guide.</p>

                        </div>
                    </li>
              
      
                </ul>
            </div>
            <div class="uk-width-1-3@l uk-width-1-3@m uk-width-1-1@s">
                <aside class="uk-margin-medium-bottom">
                    <h5 class="uk-text-uppercase uk-margin-remove-bottom">Our Advantage</h5>
                    <ul class="uk-list uk-list-divider idz-popular-widget">
                        <li>
                            <div class="uk-grid-small" data-uk-grid>
                                <div class="uk-width-auto"> <i class="fa fa-3x fa-briefcase uk-margin-small-top"></i> </div>
                                <div class="uk-width-expand uk-margin-small-left">
                                    <h5 class="uk-margin-remove-bottom">Robust Framework</h5>
                                    <p class="uk-margin-small-top">voluptatibus maiores consequatur aut perferendis doloribus asperiores</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="uk-grid-small" data-uk-grid>
                                <div class="uk-width-auto"> <i class="fa fa-3x fa-cube uk-margin-small-top"></i> </div>
                                <div class="uk-width-expand uk-margin-small-left">
                                    <h5 class="uk-margin-remove-bottom">Modern &amp; Clean</h5>
                                    <p class="uk-margin-small-top">voluptatibus maiores consequatur aut perferendis doloribus asperiores</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="uk-grid-small" data-uk-grid>
                                <div class="uk-width-auto"> <i class="fa fa-3x fa-money uk-margin-small-top"></i> </div>
                                <div class="uk-width-expand uk-margin-small-left">
                                    <h5 class="uk-margin-remove-bottom">Competitive Price</h5>
                                    <p class="uk-margin-small-top">voluptatibus maiores consequatur aut perferendis doloribus asperiores</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </aside>
                
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Katibu\Desktop\Projects\chatdoc_new\resources\views/front/index.blade.php ENDPATH**/ ?>