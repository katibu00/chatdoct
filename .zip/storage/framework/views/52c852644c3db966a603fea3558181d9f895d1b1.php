<?php $__env->startSection('PageTitle','Contact Us'); ?>
<?php $__env->startSection('content'); ?>

<section id="pagetitle-container">
    <div class="uk-container">
        <div class="uk-grid">
            <div class="uk-width-1-1">
                <ul class="uk-breadcrumb uk-margin-top uk-float-right">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<section class="uk-margin-large-bottom">
    <div class="uk-container">
        <div class="uk-grid uk-margin-medium-top">
            <div class="uk-width-1-1 uk-margin-medium-bottom">
                
                <div class="uk-card uk-card-default uk-card-medium uk-margin-medium-top">
                    <div class="uk-card-body">
                        <div class="uk-child-width-1-3@m uk-grid-divider uk-grid-medium uk-grid-match" data-uk-grid>
                            <div>
                                <h6 class="uk-text-uppercase uk-margin-remove-bottom">Address</h6>
                                <p class="uk-margin-small-top">No. 15 Gubi Dam Junction, Maiduguri Road, Bauchi, Bauchi State.</p>
                                
                            </div>
                            <div>
                                <h6 class="uk-text-uppercase uk-margin-remove-bottom">Phone Numbers</h6>
                                <p class="uk-margin-small-top">+234 806 178 9101, +234 809 697 8454</p>
                                
                            </div>
                            <div>
                                <h6 class="uk-text-uppercase uk-margin-remove-bottom">Email Address</h6>
                                <p class="uk-margin-small-top">support@chatdoct.com</p>
                               
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
            
            <div class="uk-width-1-2@l uk-width-1-2@m uk-width-1-1@s">
                <h3>Drop Us a line</h3>
                <form id="contact-form" class="uk-form">
                    <div class="uk-margin uk-width-2-3">
                        <input class="uk-input" id="name" value="" type="text" placeholder="Full name"> </div>
                    <div class="uk-margin uk-width-2-3">
                        <input class="uk-input" id="email" value="" type="email" placeholder="Email"> </div>
                    <div class="uk-margin uk-width-2-3">
                        <input class="uk-input" id="subject" value="" type="text" placeholder="Subject"> </div>
                    <div class="uk-margin">
                        <textarea class="uk-textarea" id="message" rows="5" placeholder="Message"></textarea>
                    </div>
                    <div>
                        <button class="uk-button uk-button-primary uk-float-left" id="buttonsend" type="submit" name="submit">Send Message</button>
                        <div class="idz-contact-loading uk-float-left uk-margin-left" style="display: none;"><span data-uk-spinner></span>Please wait..</div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Katibu\Desktop\Projects\chatdoc_new\resources\views/front/contact.blade.php ENDPATH**/ ?>