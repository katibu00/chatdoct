<!-- ======= Top Bar ======= -->
<?php if(auth()->guard()->check()): ?>
<?php else: ?>
<section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
      <?php if(Route::has('register')): ?>
        <i class="icofont-user-suited"> </i><a href="">&nbsp;Doctor Sign-Up&nbsp;</a>
      <?php endif; ?>
      | 
      <i class="icofont-user"></i><a href="<?php echo e(route('register')); ?>">&nbsp;Patient Sign-Up</a>
        <!--<i class="bi bi-phone-fill phone-icon"></i> +1 5589 55488 55-->
      </div>
      <!--<div class="social-links d-none d-md-block">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div> -->
    </div>
  </section>
  <?php endif; ?>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center" style="border-bottom: 1px ridge #ece5e5;">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="http://chatdoc.com.ng/"> <i class="icofont-stethoscope-alt"></i>Chat<span style="color:#444444;">Doc</span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="<?php echo e(route('index')); ?>">Home</a></li>
          <li><a class="nav-link scrollto" href="<?php echo e(route('index')); ?>#about">About</a></li>
          <li><a class="nav-link scrollto" href="<?php echo e(route('medicalDevices')); ?>">Devices</a></li>
          <li><a class="nav-link scrollto " href="<?php echo e(route('index')); ?>#howitworks">How It Works</a></li>
          <li><a class="nav-link scrollto" href="<?php echo e(route('index')); ?>#team">Doctors</a></li>
          <!--<li><a class="nav-link scrollto" href="#contact">Contact</a></li>-->
          <li><a class="nav-link scrollto" href="<?php echo e(route('index')); ?>#faq">FAQs</a></li>
          <?php if(Route::has('login')): ?>
         
          <?php if(auth()->guard()->check()): ?>
          
          <li class="dropdown"><a href="#"><span><?php echo e(Auth::user()->name); ?></span> <i class="bi bi-chevron-down"></i></a>
            <ul class="dropdown-active">
              <li><a href="<?php echo e(route('login')); ?>">Dashboard</a></li>
              
            </ul>
          </li>      
                
            <?php else: ?>
            <li><b><a class="nav-link" href="<?php echo e(route('login')); ?>"><span class="icofont-ui-lock">&nbsp;Login</span> </a></b></li>
            <?php endif; ?>
          <?php endif; ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header --><?php /**PATH C:\Users\Katibu\Desktop\Projects\chatdoc_new\resources\views/front/layouts/navigation.blade.php ENDPATH**/ ?>