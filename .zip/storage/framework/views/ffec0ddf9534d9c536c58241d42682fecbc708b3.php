
<?php $__env->startSection('PageTitle','Doctor Application Form'); ?>

<?php $__env->startSection('content'); ?>



	<!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">
     
            <!--begin::Basic info-->
            <div class="card mb-5 mb-xl-10">
                <!--begin::Card header-->
                <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse" data-bs-target="#kt_account_profile_details" aria-expanded="true" aria-controls="kt_account_profile_details">
                    <!--begin::Card title-->
                    <div class="card-title m-0">
                        <h3 class="fw-bolder m-0">Doctor Application Form</h3>
                    </div>
                    <!--end::Card title-->
                </div>
                <!--begin::Card header-->
                <!--begin::Content-->
                <div id="kt_account_profile_details" class="collapse show">
                    <!--begin::Form-->
                    <form class="form" action="<?php echo e(route('doctor.apply')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <!--begin::Card body-->
                        <div class="card-body border-top p-9">


                            <!--begin::Input group-->
                            <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label fw-bold fs-6">Profile Picture</label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8">
                                    <!--begin::Image input-->
                                    <div class="image-input image-input-outline" data-kt-image-input="true" style="background-image: url(/assets/media/avatars/blank.png)">
                                        <!--begin::Preview existing avatar-->
                                        <div class="image-input-wrapper w-125px h-125px" style="background-image: <?php if(Auth::user()->picture == 'default.png'): ?> url(/uploads/default.png) <?php else: ?> url(/uploads/avatar/<?php echo e(Auth::user()->picture); ?>) <?php endif; ?>" ></div>
                                        <!--end::Preview existing avatar-->
                                        <!--begin::Label-->
                                        <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change image">
                                            <i class="bi bi-pencil-fill fs-7"></i>
                                            <!--begin::Inputs-->
                                            <input type="file" name="image" accept=".png, .jpg, .jpeg" />
                                            
                                            <!--end::Inputs-->
                                        </label>
                                        <!--end::Label-->
                                        <!--begin::Cancel-->
                                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" title="Cancel avatar">
                                            <i class="bi bi-x fs-2"></i>
                                        </span>
                                        <!--end::Cancel-->
                                        <!--begin::Remove-->
                                        
                                        <!--end::Remove-->
                                    </div>
                                    <!--end::Image input-->
                                    <!--begin::Hint-->
                                    <div class="form-text">Allowed file types: png, jpg, jpeg.</div>
                                    <!--end::Hint-->
                                </div>
                                <!--end::Col-->
                            </div>
                            <!--end::Input group-->



                            <!--begin::Input group-->
                            <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label required fw-bold fs-6">Full Name</label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8">
                                    <!--begin::Row-->
                                    <div class="row">
                                        <!--begin::Col-->
                                        <div class="col-lg-4 fv-row">
                                            <input type="text" name="first_name" class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" placeholder="First name" value="<?php echo e(Auth::user()->first_name); ?>" />
                                        </div>
                                        <!--end::Col-->
                                        <!--begin::Col-->
                                        <div class="col-lg-4 fv-row">
                                            <input type="text" name="middle_name" class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" placeholder="Middle name" value="<?php echo e(Auth::user()->middle_name); ?>" />
                                        </div>
                                        <!--end::Col-->
                                        <div class="col-lg-4 fv-row">
                                            <input type="text" name="last_name" class="form-control form-control-lg form-control-solid " placeholder="Last name" value="<?php echo e(Auth::user()->last_name); ?>" />
                                        </div>
                                        <!--end::Col-->
                                    </div>
                                    <!--end::Row-->
                                </div>
                                <!--end::Col-->
                            </div>
                            <!--end::Input group-->
                  


                            <!--begin::Input group-->
                            <div class="row mb-6">
                            <!--begin::Label-->
                            <label class="col-lg-4 col-form-label fw-bold fs-6">
                                <span class="required">Rank</span>
                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="Phone number must be active"></i>
                            </label>
                            <!--end::Label-->
                            <!--begin::Col-->
                            <div class="col-lg-8 fv-row">
                                <select class="form-select form-select-solid" data-control="select2" data-hide-search="true" data-placeholder="Select Rank" name="rank">
                                    <option value=""></option>
                                    <option value="Professor">Professor</option>
                                    <option value="Consultant">Consultant</option>
                                    <option value="Resident Doctor">Resident Doctor</option>
                                    <option value="Medical Officer">Medical Officer</option>
                                </select>                                  
                            </div>
                                <!--end::Col-->
                            </div>
                            <!--end::Input group-->

                            <!--begin::Input group-->
                            <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label fw-bold fs-6">
                                    <span class="required">Speciality</span>
                                    
                                </label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8 fv-row">
                                    <select class="form-select form-select-solid" data-control="select2" multiple data-hide-search="false" data-placeholder="Select Specialities" name="speciality[]">
                                        <option value=""></option>
                                        <option value="Dermotology">Dermotology</option>
                                        <option value="Immunology">Immunology</option>
                                        <option value="Radiology">Radiology</option>
                                        <option value="Family Medicine">Family Medicine</option>
                                        <option value="Internal Medicine">Internal Medicine</option>
                                        <option value="Neurology">Neurology</option>
                                        <option value="Cardiology">Cardiology</option>
                                        <option value="Obstetrics">Obstetrics</option>
                                        <option value="Gynacology">Gynacology</option>
                                        <option value="Opthalmology">Opthalmology</option>
                                        <option value="Haematology">Haematology</option>
                                        <option value="Paediatrics">Paediatrics</option>
                                        <option value="Psychiatrics">Psychiatrics</option>
                                        <option value="Rheumatology">Rheumatology</option>
                                        <option value="Oncology">Oncology</option>
                                        <option value="General Surgery">General Surgery</option>
                                        <option value="Urology">Urology</option>
                                        <option value="Radiology">Radiology</option>
                                        <option value="Endocrinolgy">Endocrinolgy</option>
                                        <option value="Orthopaedics">Orthopaedics</option>
                                        <option value="Plastic Surgery">Plastic Surgery</option>
                                        <option value="Gastroenterology">Gastroenterology</option>
                                        <option value="Dental Surgery">Dental Surgery</option>
                                        <option value="Maxilofacial surgery">Maxilofacial surgery</option>
                                        <option value="ENT">ENT</option>
                                        <option value="Nephrology">Nephrology</option>
                                        <option value="General Practitioner">General Practitioner</option>
                                       
                                    </select>                                  
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <!--end::Input group-->


                  
                            <!--begin::Input group-->
                            <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label fw-bold fs-6">
                                    <span class="required">Contact Phone</span>
                                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="Phone number must be active"></i>
                                </label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8 fv-row">
                                    <input type="tel" name="phone" class="form-control form-control-lg form-control-solid" placeholder="Phone number" value="" />
                                </div>
                                <!--end::Col-->
                            </div>
                            <!--end::Input group-->
                            <!--begin::Input group-->
                            <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label fw-bold fs-6">Years of Experience</label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8 fv-row">
                                    <input type="text" name="experience" class="form-control form-control-lg form-control-solid" placeholder="Years of Experience" value="" />
                                </div>
                                <!--end::Col-->
                            </div>
                            <!--end::Input group-->


                            <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label fw-bold fs-6">
                                    <span class="required">Languages</span>
                                </label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8 fv-row">
                                    <select class="form-select form-select-solid" data-control="select2" multiple data-hide-search="false" data-placeholder="Select languages" name="languages[]">
                                        <option value=""></option>
                                        <option value="English">English</option>
                                        <option value="Pidgin">Pidgin</option>
                                        <option value="Hausa">Hausa</option>
                                        <option value="Yoruba">Yoruba</option>
                                        <option value="Igbo">Igbo</option>
                                        <option value="Fulfulde">Fulfulde</option>
                                        <option value="Tiv">Tiv</option>
                                        <option value="Kanuri">Kanuri</option>
                                        <option value="Ibibio">Ibibio</option>
                                       
                                       
                                    </select>                                  
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <!--end::Input group-->


                                
                            <!--begin::Input group-->
                            <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label fw-bold fs-6">Practice License/Certificate of Registration</label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8">
                                    <!--begin::Image input-->
                                    <div class="image-input image-input-outline" data-kt-image-input="true" style="background-image: url(/assets/media/avatars/blank.png)">
                                        <!--begin::Preview existing avatar-->
                                        <div class="image-input-wrapper w-125px h-150px" style="background-image: url(/uploads/default.png)" ></div>
                                        <!--end::Preview existing avatar-->
                                        <!--begin::Label-->
                                        <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change image">
                                            <i class="bi bi-pencil-fill fs-7"></i>
                                            <!--begin::Inputs-->
                                            <input type="file" name="certificate" accept=".png, .jpg, .jpeg" />
                                            
                                            <!--end::Inputs-->
                                        </label>
                                        <!--end::Label-->
                                        <!--begin::Cancel-->
                                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" title="Cancel avatar">
                                            <i class="bi bi-x fs-2"></i>
                                        </span>
                                        <!--end::Cancel-->
                                        <!--begin::Remove-->
                                        
                                        <!--end::Remove-->
                                    </div>
                                    <!--end::Image input-->
                                    <!--begin::Hint-->
                                    <div class="form-text">Allowed file types: png, jpg, jpeg.</div>
                                    <!--end::Hint-->
                                </div>
                                <!--end::Col-->
                            </div>
                            <!--end::Input group-->

                               <!--begin::Input group-->
                               <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label fw-bold fs-6">Folio Number</label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8 fv-row">
                                    <input type="text" name="folio" class="form-control form-control-lg form-control-solid" placeholder="Enter your Folio Number"  />
                                </div>
                                <!--end::Col-->
                            </div>
                            <!--end::Input group-->


                            <!--begin::Input group-->
                      
                            <!--end::Input group-->
                       
                            <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label fw-bold fs-6">Sex</label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8 fv-row">
                                    <select name="sex" aria-label="Select Sex" data-control="select2" data-placeholder="Select sex.." class="form-select form-select-solid form-select-lg">
                                        <option value=""></option>
                                        <option data-bs-offset="-39600" value="Male" <?php echo e(Auth::user()->sex == 'Male'?"Selected":""); ?>>Male</option>
                                        <option data-bs-offset="-39600" value="Female" <?php echo e(Auth::user()->sex == 'Female'?"Selected":""); ?>>Female</option>
                                    </select>                                
                                </div>
                                <!--end::Col-->
                            </div>



                            <!--begin::Input group-->
                            <div class="row mb-6">
                                <!--begin::Label-->
                                <label class="col-lg-4 col-form-label required fw-bold fs-6">Address</label>
                                <!--end::Label-->
                                <!--begin::Col-->
                                <div class="col-lg-8 fv-row">
                                 <textarea name="address" class="form-control form-control-lg form-control-solid"></textarea>
                                </div>
                                <!--end::Col-->
                            </div>
                            <!--end::Input group-->
                   
                            
             


                                     <!--begin::Input group-->
                                     <div class="row mb-6">
                                        <!--begin::Label-->
                                        <label class="col-lg-4 col-form-label required fw-bold fs-6">State and LGA</label>
                                        <!--end::Label-->
                                        <!--begin::Col-->
                                        <div class="col-lg-8">
                                            <!--begin::Row-->
                                            <div class="row">
                                                <!--begin::Col-->
                                                <div class="col-lg-6 fv-row">
                                                    
                                                        <select
                                                        onchange="toggleLGA(this);"
                                                        name="state"
                                                        id="state"
                                                        class="form-select form-select-solid"
                                                        data-placeholder="Select State"
                                                        data-control="select2"
                                                        >
                                                        <option value="" selected="selected">- Select State-</option>
                                                        <option value="Abia" <?php if(@$user->state == 'Abia'): ?> selected <?php endif; ?>>Abia</option>
                                                        <option value="Adamawa" <?php if(@$user->state == 'Adamawa'): ?> selected <?php endif; ?>>Adamawa</option>
                                                        <option value="AkwaIbom" <?php if(@$user->state == 'AkwaIbom'): ?> selected <?php endif; ?>>AkwaIbom</option>
                                                        <option value="Anambra" <?php if(@$user->state == 'Anambra'): ?> selected <?php endif; ?>>Anambra</option>
                                                        <option value="Bauchi" <?php if(@$user->state == 'Bauchi'): ?> selected <?php endif; ?>>Bauchi</option>
                                                        <option value="Bayelsa" <?php if(@$user->state == 'Bayelsa'): ?> selected <?php endif; ?>>Bayelsa</option>
                                                        <option value="Benue" <?php if(@$user->state == 'Benue'): ?> selected <?php endif; ?>>Benue</option>
                                                        <option value="Borno" <?php if(@$user->state == 'Borno'): ?> selected <?php endif; ?>>Borno</option>
                                                        <option value="Cross River" <?php if(@$user->state == 'Cross River'): ?> selected <?php endif; ?>>Cross River</option>
                                                        <option value="Delta" <?php if(@$user->state == 'Delta'): ?> selected <?php endif; ?>>Delta</option>
                                                        <option value="Ebonyi" <?php if(@$user->state == 'Ebonyi'): ?> selected <?php endif; ?>>Ebonyi</option>
                                                        <option value="Edo" <?php if(@$user->state == 'Edo'): ?> selected <?php endif; ?>>Edo</option>
                                                        <option value="Ekiti" <?php if(@$user->state == 'Ekiti'): ?> selected <?php endif; ?>>Ekiti</option>
                                                        <option value="Enugu" <?php if(@$user->state == 'Enugu'): ?> selected <?php endif; ?>>Enugu</option>
                                                        <option value="FCT" <?php if(@$user->state == 'FCT'): ?> selected <?php endif; ?>>FCT</option>
                                                        <option value="Gombe" <?php if(@$user->state == 'Gombe'): ?> selected <?php endif; ?>>Gombe</option>
                                                        <option value="Imo" <?php if(@$user->state == 'Imo'): ?> selected <?php endif; ?>>Imo</option>
                                                        <option value="Jigawa" <?php if(@$user->state == 'Jigawa'): ?> selected <?php endif; ?>>Jigawa</option>
                                                        <option value="Kaduna" <?php if(@$user->state == 'Kaduna'): ?> selected <?php endif; ?>>Kaduna</option>
                                                        <option value="Kano" <?php if(@$user->state == 'Kano'): ?> selected <?php endif; ?>>Kano</option>
                                                        <option value="Katsina" <?php if(@$user->state == 'Katsina'): ?> selected <?php endif; ?>>Katsina</option>
                                                        <option value="Kebbi" <?php if(@$user->state == 'Kebbi'): ?> selected <?php endif; ?>>Kebbi</option>
                                                        <option value="Kogi" <?php if(@$user->state == 'Kogi'): ?> selected <?php endif; ?>>Kogi</option>
                                                        <option value="Kwara" <?php if(@$user->state == 'Kwara'): ?> selected <?php endif; ?>>Kwara</option>
                                                        <option value="Lagos" <?php if(@$user->state == 'Lagos'): ?> selected <?php endif; ?>>Lagos</option>
                                                        <option value="Nasarawa" <?php if(@$user->state == 'Nasarawa'): ?> selected <?php endif; ?>>Nasarawa</option>
                                                        <option value="Niger" <?php if(@$user->state == 'Niger'): ?> selected <?php endif; ?>>Niger</option>
                                                        <option value="Ogun" <?php if(@$user->state == 'Ogun'): ?> selected <?php endif; ?>>Ogun</option>
                                                        <option value="Ondo" <?php if(@$user->state == 'Ondo'): ?> selected <?php endif; ?>>Ondo</option>
                                                        <option value="Osun" <?php if(@$user->state == 'Osun'): ?> selected <?php endif; ?>>Osun</option>
                                                        <option value="Oyo" <?php if(@$user->state == 'Oyo'): ?> selected <?php endif; ?>>Oyo</option>
                                                        <option value="Plateau" <?php if(@$user->state == 'Plateau'): ?> selected <?php endif; ?>>Plateau</option>
                                                        <option value="Rivers" <?php if(@$user->state == 'Rivers'): ?> selected <?php endif; ?>>Rivers</option>
                                                        <option value="Sokoto" <?php if(@$user->state == 'Sokoto'): ?> selected <?php endif; ?>>Sokoto</option>
                                                        <option value="Taraba" <?php if(@$user->state == 'Taraba'): ?> selected <?php endif; ?>>Taraba</option>
                                                        <option value="Yobe" <?php if(@$user->state == 'Yobe'): ?> selected <?php endif; ?>>Yobe</option>
                                                        <option value="Zamfara <?php if(@$user->state == 'Zamfara'): ?> selected <?php endif; ?>">Zamfara</option>
                                                        </select>
                                                 
                                                </div>
                                                <!--end::Col-->
                                                <!--begin::Col-->
                                                <div class="col-lg-6 fv-row">
                                                    <select
                                                        name="lga"
                                                        id="lga"
                                                        class="form-select form-select-solid select-lga"
                                                        data-placeholder="LGA"
                                                        data-control="select2"
                                                        required
                                                    >
                                                    </select>

                                                </div>
                                           
                                            </div>
                                            <!--end::Row-->
                                        </div>
                                        <!--end::Col-->
                                    </div>
                                    <!--end::Input group-->


                        </div>
                        <!--end::Card body-->
                        <!--begin::Actions-->
                        <div class="card-footer d-flex justify-content-end py-6 px-9">
                            <button type="reset" class="btn btn-light btn-active-light-primary me-2">Discard</button>
                            <button type="submit" class="btn btn-primary" id="kt_account_profile_details_submit">Save Changes</button>
                        </div>
                        <!--end::Actions-->
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Content-->
            </div>
            <!--end::Basic info-->

        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>


    <script src="/assets/js/custom/account/settings/signin-methods.js"></script>
    <script src="/assets/js/custom/account/settings/profile-details.js"></script>
    <script src="/assets/js/custom/account/settings/deactivate-account.js"></script>
    <script src="/assets/js/custom/modals/two-factor-authentication.js"></script>
    <script src="/assets/js/custom/widgets.js"></script>
    <script src="/assets/js/custom/apps/chat/chat.js"></script>
    <script src="/assets/js/custom/modals/create-app.js"></script>
    <script src="/assets/js/custom/modals/upgrade-plan.js"></script>
	<script src="/assets/js/custom/pages/projects/project/project.js"></script>

<script src="/lga/lga2.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Katibu\Desktop\Projects\chatdoc\resources\views/doctor/application.blade.php ENDPATH**/ ?>