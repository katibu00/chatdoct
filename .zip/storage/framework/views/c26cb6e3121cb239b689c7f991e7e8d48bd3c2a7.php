<!DOCTYPE html>
<html lang="en-gb" dir="ltr">

<head>
    <!-- Standard Meta -->
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Site Properties -->
    <title>ChatDoct -  <?php echo $__env->yieldContent('PageTitle'); ?></title>
    <link rel="shortcut icon" href="/uploads/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon-precomposed" href="/front/images/apple-touch-icon.png">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <!-- CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="/front/css/uikit.min.css">
    <link rel="stylesheet" href="/front/css/style.css">
    <link rel="stylesheet" href="/front/css/components/swiper.css">
    <link rel="stylesheet" href="/front/css/components/font-awesome.css"> </head>

<body>
    <header>
        <div class="uk-container">
            <div class="uk-grid">
                <div class="uk-width-2-5@l uk-width-1-3@m uk-width-1-4@s">
                    <!-- logo header begin -->
                    <div id="header-logo">
                        <a class="uk-logo" href="<?php echo e(route('homepage')); ?>"><img src="/uploads/logo.jpg" width="80px" height="80px" alt="ChatDoc Logo" /></a>
                    </div>
                    <!-- logo header end -->
                </div>
                <div class="uk-width-3-5@l uk-width-2-3@m uk-width-3-4@s uk-visible@m">
                    <div class="uk-grid">
                        <div class="uk-width-1-2">
                            <div class="idz-mini-nav uk-align-right">
                                
                            </div>
                        </div>
                        <div class="uk-width-1-2 phone-number">
                            <h2 class="uk-align-right">+2348080607180</h2>
                        </div>
                    </div>
                </div>
                <div class="uk-width-1-1">
                    <hr>
                    <!-- Main navigation begin -->
                    <nav class="uk-navbar-container uk-visible@m" data-uk-navbar style="z-index: 980;" data-uk-sticky="animation: uk-animation-slide-top; cls-active: uk-sticky; cls-inactive: uk-navbar-container; bottom: #offset">
                        <div class="uk-navbar-left">
                            <ul class="uk-navbar-nav">
                           
                                <li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
                                <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                                <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                            
                            </ul>
                        </div>
                        <div class="uk-navbar-right uk-visible@l">
                            <div data-uk-margin> <a class="uk-button uk-button-default" href="<?php echo e(route('login')); ?>">Login</a> <a class="uk-button uk-button-primary"  href="<?php echo e(route('register')); ?>">Create Account</a> </div>
                        </div>
                    </nav>
                    <!-- Main navigation end -->
                    <!-- Mobile navigation begin -->
                    <a class="uk-button uk-align-center idz-mobile-nav uk-hidden@m" href="#modal-full" data-uk-icon="icon: menu" data-uk-toggle>Menu</a>
                    <div id="modal-full" class="uk-modal-full" data-uk-modal>
                        <div class="uk-modal-dialog">
                            <button class="uk-modal-close-full uk-close-large" type="button" data-uk-close></button>
                            <div data-uk-height-viewport>
                                <div class="uk-position-cover uk-overlay uk-overlay-primary uk-flex uk-flex-center uk-flex-middle">
                                    <ul class="uk-nav-primary uk-nav-parent-icon" data-uk-nav>
                                      <li><a href="#">Home</a></li>
                                      <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                                      <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                                      <li><a href="<?php echo e(route('login')); ?>"><button style="color:black" class="uk-button uk-button-danger uk-text-primary">Login</button></a></li>
                                    </ul>
                                  
                                </div>
                              
                                
                              
                            </div>
                        </div>
                    </div>
                    <!-- Mobile navigation end -->
                </div>
            </div>
        </div>
    </header>
     <?php echo $__env->yieldContent('content'); ?>
    <footer>
        <div class="uk-container uk-light">
            <div class="uk-grid uk-margin-large-top">
                <div class="uk-width-1-4@l uk-width-1-5@m uk-width-1-3@s">
                    <ul class="uk-list">
                        <li>Get in Touch</li>
                        <li>support@chatdoct.com</li>
                        <li>+234 808 060 7180</li>
                    </ul>
                </div>
                <div class="uk-width-1-4@l uk-width-1-5@m uk-width-1-3@s">
                    <ul class="uk-list">
                      
                      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('homepage')); ?>">Home</a> </li>
                      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('about')); ?>">About Us</a> </li>
                      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact Us</a> </li>
                        <li class="nav-item"><a class="dropdown-item" href="<?php echo e(route('doctor.apply')); ?>">Apply as Doctor</a></li>

                    </ul>
                </div>
                <div class="uk-width-1-4@l uk-width-1-5@m uk-width-1-3@s">
                    <ul class="uk-list">
                      <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                      <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                      <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                    </ul>
                </div>
                <div class="uk-width-1-4@l uk-width-2-5@m uk-width-1-1@s">
                    <div class="uk-align-right idz-footer-adjust">
                        <a href="/front/" class="uk-icon-button uk-margin-small-right" data-uk-icon="icon: facebook"></a>
                        <a href="/front/" class="uk-icon-button  uk-margin-small-right" data-uk-icon="icon: twitter"></a>
                        <a href="/front/" class="uk-icon-button  uk-margin-small-right" data-uk-icon="icon: instagram"></a>
                        <a href="/front/" class="uk-icon-button" data-uk-icon="icon: youtube"></a>
                    </div>
                    <div class="idz-footer-download uk-visible@m">
                        <a href=""><img src="/front/images/download_apple.png" alt=""></a>
                        <a href=""><img src="/front/images/download_google.png" alt=""></a>
                    </div>
                </div>
                <div class="uk-width-1-1 uk-margin-large-top uk-margin-large-bottom">
                    <!-- logo footer begin -->
                    <div id="footer-logo">
                        <a class="uk-logo" href=""><img src="/uploads/logo.jpg" width="50px" height="50px" alt="chatdoc logo" /></a>
                        <p><span>Copyright ©2022 ChatDoc Nigeria. All Rights Reserved.</span></p>
                    </div>
                    <!-- logo footer end -->
                    <hr>
                    <div class="uk-margin-small-top">
                        <p>Chatdoc is a social enterprise that helps underserviced communities in Nigeria to access qualitative healthcare virtually through Telemedicine.</p>
                    </div>
                </div>
            </div>
        </div>
        <a class="uk-inline" href="/front/#" data-uk-totop data-uk-scroll data-uk-scrollspy="cls: uk-animation-fade; hidden: true; offset-top: 100px; repeat: true"></a>
    </footer>
    <!-- Javascript -->
    <script src="/front/js/jquery.js"></script>
    <script src="/front/js/uikit.min.js"></script>
    <script src="/front/js/uikit-icons.min.js"></script>
    <script src="/front/js/components/mediaelement.js"></script>    
    <script src="/front/js/config.js"></script>
</body>

</html><?php /**PATH C:\Users\Katibu\Desktop\Projects\chatdoc_new\resources\views/front/layouts/master.blade.php ENDPATH**/ ?>