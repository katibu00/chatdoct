<template>

<div id="main-app">
    <chatComponent2 />
</div>

</template>

<script>

import chatComponent2 from "./ChatApp2.vue";

export default {
    components:{
        chatComponent2
    }
}
</script>
