<h1>Forgot Password</h1>

<p>{!! $body !!}</p>
<br/>
<a href="{{ $action_link }}">Reset Password</a>