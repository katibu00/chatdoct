@extends('layouts.master')
@section('PageTitle','Chats')
@section('content')

<major-app></major-app>


@endsection
